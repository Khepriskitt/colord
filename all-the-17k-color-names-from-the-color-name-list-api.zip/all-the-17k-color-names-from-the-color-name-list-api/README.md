# All the 17k color names from the color-name-list API

A Pen created on CodePen.

Original URL: [https://codepen.io/meodai/pen/VMpNdQ](https://codepen.io/meodai/pen/VMpNdQ).

Showing off all the colors from: https://github.com/meodai/color-names/